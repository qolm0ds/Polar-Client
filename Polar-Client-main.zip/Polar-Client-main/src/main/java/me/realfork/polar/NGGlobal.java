package me.jacktym.aiomacro;

public class NGGlobal {

    public static final String MOD_ID = "AIOM";
    public static final String MOD_NAME = "All-In-One Macro";
    public static final String VERSION = "Release v1.8.0";

    public static final String NG_CLIENT_PROXY = "me.jacktym.aiomacro.proxy.ClientProxy";
    public static final String NG_COMMON_PROXY = "me.jacktym.aiomacro.proxy.CommonProxy";

}