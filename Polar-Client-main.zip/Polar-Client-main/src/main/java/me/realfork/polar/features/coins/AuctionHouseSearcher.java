package me.jacktym.aiomacro.features.coins;

public class AuctionHouseSearcher {
}
