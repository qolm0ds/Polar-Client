package me.jacktym.aiomacro.features;

public class AntiKB {

    /*public static void explosion(S27PacketExplosion packet) {
        if (cancelKnockBack()) {
            Main.mcPlayer.motionX -= packet.getX();
            if (!Main.mcPlayer.getHeldItem().getDisplayName().contains("Jerry-chine Gun")) {
                Main.mcPlayer.motionY -= packet.getY();
            }
            Main.mcPlayer.motionZ -= packet.getZ();
        }
    }

    public static boolean entityVelocity(S12PacketEntityVelocity packet) {
        if (cancelKnockBack()) {
            return Main.mcWorld.getEntityByID(packet.getEntityID()) == Main.mcPlayer;
        }
        return false;
    }

    private static boolean cancelKnockBack() {
        if (Main.mcWorld.getScoreboard().getObjectiveInDisplaySlot(1) != null && Main.mcWorld.getScoreboard().getObjectiveInDisplaySlot(1) != null && !Main.mcWorld.getScoreboard().getObjectiveInDisplaySlot(1).getDisplayName().contains("SKYBLOCK") || !AIOMVigilanceConfig.antiKB || !Main.notNull) {
            return false;
        }

        if (Main.mcPlayer.getHeldItem() != null) {
            return !Main.mcPlayer.getHeldItem().getDisplayName().contains("Jerry-chine Gun") || !Main.mcPlayer.getHeldItem().getDisplayName().contains("Bonzo's Staff") || !Main.mcPlayer.getHeldItem().getDisplayName().contains("Grappling Hook");
        }
        return true;
    }*/
}
